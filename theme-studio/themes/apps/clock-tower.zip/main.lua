-- Lua 5.3 · 64×64 · all composition is controlled here.
-- Native RGB565 delta decoder and native glyph spans.
local hour, minute, secondText, hm
local phase = 0
local week = {"SUN","MON","TUE","WED","THU","FRI","SAT"}
function second()
  hour, minute = clock.format("%H"), clock.format("%M")
  secondText = clock.format("%S")
  hm = hour .. ":" .. minute
end
function start()
  second()
  phase = rng.int(0, 2000)
end
function button(key)
  if key == "A" then phase = rng.int(0, 10000) end
end
function draw()
  media.draw("clock-tower", 0, 0, clock.millis() + phase)
  local h=(clock.value("hour")%12+clock.value("minute")/60)*math.pi/6-math.pi/2
  local m=(clock.value("minute")+clock.value("second")/60)*math.pi/30-math.pi/2
  for i=0,11 do
    local a=i*math.pi/6
    gfx.pixel(33+math.sin(a)*18,32-math.cos(a)*18,"#84ac3d")
  end
  gfx.line(33,32,33+math.cos(h)*11,32+math.sin(h)*11,"#7eae42")
  gfx.line(33,32,33+math.cos(m)*16,32+math.sin(m)*16,"#b4cf55")
end
