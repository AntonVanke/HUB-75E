-- Lua 5.3 · 64×64 · all composition is controlled here.
-- Native RGB565 delta decoder and native glyph spans.
local hour, minute, secondText, hm
local phase = 0
local week = {"SUN","MON","TUE","WED","THU","FRI","SAT"}
function second()
  hour, minute = clock.format("%H"), clock.format("%M")
  secondText = clock.format("%S")
  hm = hour .. ":" .. minute
end
function start()
  second()
  phase = rng.int(0, 2000)
end
function button(key)
  if key == "A" then phase = rng.int(0, 10000) end
end
function draw()
  media.draw("twinkle-twinkle", 0, 0, clock.millis() + phase)
  font.draw("bold",10,1,hm,"#ffcc31")
end
