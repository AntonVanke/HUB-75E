-- Lua 5.3 · 64×64 · all composition is controlled here.
-- Native RGB565 delta decoder and native glyph spans.
local hour, minute, secondText, hm
local phase = 0
local week = {"SUN","MON","TUE","WED","THU","FRI","SAT"}
function second()
  hour, minute = clock.format("%H"), clock.format("%M")
  secondText = clock.format("%S")
  hm = hour .. ":" .. minute
end
function start()
  second()
  phase = rng.int(0, 2000)
end
function button(key)
  if key == "A" then phase = rng.int(0, 10000) end
end
function draw()
  media.draw("nyan-cat", 0, 0, clock.millis() + phase)
  font.draw("mario",2,45,clock.format("%m-%d"),"#f8d900")
  gfx.text(39,46,hm,"#ffffff")
  gfx.text(5,58,"HAVE A NYAN DAY","#64ef20")
end
