-- Lua 5.3 · 64×64 · all composition is controlled here.
-- Native RGB565 delta decoder and native glyph spans.
local hour, minute, secondText, hm
local phase = 0
local week = {"SUN","MON","TUE","WED","THU","FRI","SAT"}
function second()
  hour, minute = clock.format("%H"), clock.format("%M")
  secondText = clock.format("%S")
  hm = hour .. ":" .. minute
end
function start()
  second()
  phase = rng.int(0, 2000)
end
function button(key)
  if key == "A" then phase = rng.int(0, 10000) end
end
function draw()
  media.draw("particle-time", 0, 0, clock.millis() + phase)
  font.draw("thin",6,19,hour,"#43c5fa",2)
  gfx.rect(28,25,2,2,"#a6afff")
  gfx.rect(28,33,2,2,"#a6afff")
  font.draw("thin",34,19,minute,"#9d8fff",2)
  gfx.text(3,50,week[clock.value("weekday")+1]..clock.format("%m%d"),"#85f8d2",2)
end
